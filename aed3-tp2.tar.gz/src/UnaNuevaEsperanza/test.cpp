#include "../main.h"
#include "./UnaNuevaEsperanza.h"
#include "../mini_test.h" // framework para tests unitarios

/*
**  Ejercicio 1: Una nueva esperanza
**  Tests unitarios
*/

void correr_tests_unitarios() {
    std::cout << "Acá todavía no hay nada" << std::endl;
}
